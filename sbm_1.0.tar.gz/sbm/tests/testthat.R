library(testthat)
library(sbm)

test_check("sbm")
