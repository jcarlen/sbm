library(testthat)
library(sbmt)

test_check("sbmt")
